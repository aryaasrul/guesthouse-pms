// Sync settings screen

const MaskUrl = ({ url }) => {
  const [visible, setVisible] = React.useState(false);
  const masked = url.replace(/(?<=.{32}).*(?=.{8})/, '···');
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <span style={{
        fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--text-2)',
        background: 'var(--surface)', borderRadius: 'var(--radius-sm)',
        padding: '4px 8px', flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
      }}>{visible ? url : masked}</span>
      <Btn variant="ghost" size="sm" onClick={() => setVisible(!visible)} style={{ flexShrink: 0 }}>
        {visible ? 'Sembunyikan' : 'Tampilkan'}
      </Btn>
      <Btn variant="ghost" size="sm" onClick={() => navigator.clipboard?.writeText(url)} style={{ flexShrink: 0 }}>
        Salin
      </Btn>
    </div>
  );
};

const ToggleSwitch = ({ value, onChange }) => (
  <div
    onClick={() => onChange(!value)}
    style={{
      width: 36, height: 20, borderRadius: 10,
      background: value ? 'var(--accent)' : 'var(--border)',
      position: 'relative', cursor: 'pointer', transition: 'background 150ms',
      flexShrink: 0,
    }}
  >
    <div style={{
      position: 'absolute', top: 3, left: value ? 19 : 3,
      width: 14, height: 14, borderRadius: '50%', background: '#fff',
      transition: 'left 150ms', boxShadow: '0 1px 3px rgba(0,0,0,0.15)',
    }} />
  </div>
);

const ChannelCard = ({ channel }) => {
  const [active, setActive] = React.useState(channel.status === 'active');
  const [syncing, setSyncing] = React.useState(false);
  const [editing, setEditing] = React.useState(false);
  const [url, setUrl] = React.useState(channel.icalUrl);

  const handleSync = () => {
    setSyncing(true);
    setTimeout(() => setSyncing(false), 1800);
  };

  const logoColors = { airbnb: '#FF5A5F', agoda: '#003580' };

  return (
    <Card style={{ padding: 20 }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14 }}>
        {/* Logo placeholder */}
        <div style={{
          width: 40, height: 40, borderRadius: 'var(--radius)',
          background: logoColors[channel.id] + '18',
          border: `1px solid ${logoColors[channel.id]}30`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          flexShrink: 0,
        }}>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, fontWeight: 600, color: logoColors[channel.id] }}>
            {channel.name.slice(0, 2).toUpperCase()}
          </span>
        </div>

        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{ fontSize: 14, fontWeight: 500 }}>{channel.name}</span>
              <Badge variant={active ? 'available' : 'cancelled'}>{active ? 'Aktif' : 'Nonaktif'}</Badge>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <ToggleSwitch value={active} onChange={setActive} />
            </div>
          </div>

          <div style={{ fontSize: 12, color: 'var(--text-3)', marginBottom: 12 }}>
            {channel.rooms.length} kamar terhubung · Terakhir sync: {formatTime(channel.lastSync)}, {formatDate(channel.lastSync)}
            <span style={{ marginLeft: 8, color: 'var(--status-available-fg)' }}>· {channel.eventsFound} event, {channel.eventsAdded} ditambahkan</span>
          </div>

          {/* iCal URL */}
          <div style={{ marginBottom: 12 }}>
            <div style={{ fontSize: 11, color: 'var(--text-3)', fontWeight: 500, textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: 6 }}>iCal URL</div>
            {editing ? (
              <div style={{ display: 'flex', gap: 8 }}>
                <input
                  value={url} onChange={e => setUrl(e.target.value)}
                  style={{
                    flex: 1, fontFamily: 'var(--font-mono)', fontSize: 11,
                    border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)',
                    padding: '6px 8px', background: '#fff', color: 'var(--text-1)', outline: 'none',
                  }}
                />
                <Btn variant="primary" size="sm" onClick={() => setEditing(false)}>Simpan</Btn>
                <Btn variant="ghost" size="sm" onClick={() => setEditing(false)}>Batal</Btn>
              </div>
            ) : (
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <MaskUrl url={url} />
                <Btn variant="ghost" size="sm" onClick={() => setEditing(true)} style={{ flexShrink: 0 }}>Edit</Btn>
              </div>
            )}
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <Btn variant="secondary" size="sm" onClick={handleSync} disabled={syncing}>
              {syncing ? (
                <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <span style={{ display: 'inline-block', width: 10, height: 10, border: '1.5px solid var(--text-3)', borderTopColor: 'transparent', borderRadius: '50%', animation: 'spin 600ms linear infinite' }} />
                  Menyinkronkan...
                </span>
              ) : 'Sync Sekarang'}
            </Btn>
          </div>
        </div>
      </div>
    </Card>
  );
};

const SyncLogRow = ({ log, index }) => {
  const isEven = index % 2 === 0;
  return (
    <tr style={{ background: isEven ? 'transparent' : 'rgba(242,240,236,0.5)' }}>
      <td style={{ padding: '9px 14px' }}><Badge variant={log.channel}>{log.channel === 'airbnb' ? 'Airbnb' : 'Agoda'}</Badge></td>
      <td style={{ padding: '9px 14px', fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text-2)' }}>
        {new Date(log.timestamp).toLocaleString('id-ID', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
      </td>
      <td style={{ padding: '9px 14px', fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text-2)', textAlign: 'center' }}>{log.eventsFound}</td>
      <td style={{ padding: '9px 14px', fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text-2)', textAlign: 'center' }}>{log.eventsAdded}</td>
      <td style={{ padding: '9px 14px' }}>
        <Badge variant={log.status === 'ok' ? 'available' : 'occupied'}>{log.status === 'ok' ? 'Berhasil' : 'Error'}</Badge>
      </td>
    </tr>
  );
};

const ScreenSync = () => (
  <div style={{ maxWidth: 720, display: 'flex', flexDirection: 'column', gap: 28 }}>
    {/* Channels */}
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
        <h2 style={{ fontSize: 13, fontWeight: 500, color: 'var(--text-2)', textTransform: 'uppercase', letterSpacing: '0.03em' }}>Saluran Terhubung</h2>
        <Btn variant="secondary" size="sm">+ Tambah Saluran</Btn>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {SYNC_CHANNELS.map(ch => <ChannelCard key={ch.id} channel={ch} />)}
      </div>
    </div>

    {/* Sync log */}
    <div>
      <h2 style={{ fontSize: 13, fontWeight: 500, color: 'var(--text-2)', textTransform: 'uppercase', letterSpacing: '0.03em', marginBottom: 14 }}>Riwayat Sinkronisasi</h2>
      <Card style={{ overflow: 'hidden', padding: 0 }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ borderBottom: '1px solid var(--border-subtle)' }}>
              {['Saluran', 'Waktu', 'Event Ditemukan', 'Ditambahkan', 'Status'].map((h, i) => (
                <th key={h} style={{ padding: '10px 14px', textAlign: i > 1 ? 'center' : 'left', fontSize: 11, fontWeight: 500, color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {SYNC_LOGS.map((log, i) => <SyncLogRow key={log.id} log={log} index={i} />)}
          </tbody>
        </table>
      </Card>
    </div>
  </div>
);

window.ScreenSync = ScreenSync;
