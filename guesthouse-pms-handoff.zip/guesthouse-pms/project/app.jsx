// App — router + shell

const SCREEN_META = {
  'design-system':  { title: 'Design System',    subtitle: 'Tokens, komponen, dan panduan visual' },
  'dashboard':      { title: 'Beranda',           subtitle: 'Senin, 28 April 2026' },
  'calendar':       { title: 'Kalender',          subtitle: 'Tampilan okupansi per kamar' },
  'booking-detail': { title: 'Detail Pemesanan',  subtitle: 'BK-0003 · Ahmad Fauzi' },
  'booking-form':   { title: 'Buat Pesanan',      subtitle: 'Input manual via WhatsApp / telepon' },
  'sync':           { title: 'Sinkronisasi',      subtitle: 'Kelola koneksi Airbnb & Agoda' },
  'public-room':    { title: 'Halaman Publik',    subtitle: 'Tampilan tamu · /kamar/05' },
};

const App = () => {
  const [screen, setScreen] = React.useState('dashboard');
  const meta = SCREEN_META[screen] || {};

  const actions = {
    'dashboard':     <><Btn variant="secondary" size="sm" onClick={() => setScreen('booking-form')}>+ Buat Pesanan</Btn></>,
    'calendar':      <><Btn variant="secondary" size="sm" onClick={() => setScreen('booking-form')}>+ Buat Pesanan</Btn></>,
    'booking-detail':<><Btn variant="secondary" size="sm" onClick={() => setScreen('booking-form')}>+ Buat Pesanan</Btn></>,
    'public-room':   <><span style={{fontSize:12,color:'var(--text-3)',fontFamily:'var(--font-mono)'}}>/kamar/05</span></>,
  };

  const renderScreen = () => {
    switch (screen) {
      case 'design-system':  return <ScreenDesignSystem />;
      case 'dashboard':      return <ScreenDashboard onNavigate={setScreen} />;
      case 'calendar':       return <ScreenCalendar />;
      case 'booking-detail': return <ScreenBookingDetail onNavigate={setScreen} />;
      case 'booking-form':   return <ScreenBookingForm onNavigate={setScreen} />;
      case 'sync':           return <ScreenSync />;
      case 'public-room':    return <ScreenPublicRoom />;
      default:               return <ScreenDashboard onNavigate={setScreen} />;
    }
  };

  // Public room gets no sidebar chrome
  if (screen === 'public-room') {
    return (
      <div>
        <div style={{ position: 'fixed', bottom: 20, right: 20, zIndex: 200 }}>
          <Btn variant="secondary" size="sm" onClick={() => setScreen('dashboard')} style={{ boxShadow: '0 2px 12px rgba(26,25,22,0.12)' }}>
            ← Kembali ke Admin
          </Btn>
        </div>
        <ScreenPublicRoom />
      </div>
    );
  }

  return (
    <AppLayout
      current={screen}
      onNavigate={setScreen}
      topBar={
        <TopBar
          title={meta.title}
          subtitle={meta.subtitle}
          actions={actions[screen]}
        />
      }
    >
      {renderScreen()}
    </AppLayout>
  );
};

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
