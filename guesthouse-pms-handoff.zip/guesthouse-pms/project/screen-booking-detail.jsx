// Booking detail screen

const DetailRow = ({ label, value, mono, children }) => (
  <div style={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
    <span style={{ fontSize: 11, color: 'var(--text-3)', fontWeight: 500, textTransform: 'uppercase', letterSpacing: '0.04em' }}>{label}</span>
    {children || (
      <span style={{ fontSize: 14, color: 'var(--text-1)', fontFamily: mono ? 'var(--font-mono)' : 'var(--font-sans)' }}>{value || '—'}</span>
    )}
  </div>
);

const ScreenBookingDetail = ({ onNavigate }) => {
  const booking = BOOKINGS[2]; // BK-0003 checkout today — interesting state
  const room = getRoomById(booking.roomId);
  const [notes, setNotes] = React.useState(booking.notes);
  const [editingGuest, setEditingGuest] = React.useState(false);
  const [showCancelModal, setShowCancelModal] = React.useState(false);
  const [showExtendModal, setShowExtendModal] = React.useState(false);
  const [extendDate, setExtendDate] = React.useState(booking.checkOut);
  const [status, setStatus] = React.useState(booking.status);
  const [toast, setToast] = React.useState(null);

  const showToast = (msg) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2500);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
      {/* Breadcrumb */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: 'var(--text-3)' }}>
        <span style={{ cursor: 'pointer', color: 'var(--text-2)' }} onClick={() => onNavigate('dashboard')}>Beranda</span>
        <span>›</span>
        <span style={{ cursor: 'pointer', color: 'var(--text-2)' }}>Pemesanan</span>
        <span>›</span>
        <span style={{ fontFamily: 'var(--font-mono)' }}>{booking.id}</span>
      </div>

      {/* Two-column layout */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, alignItems: 'start' }}>

        {/* Left — Booking info */}
        <Card style={{ padding: 24, display: 'flex', flexDirection: 'column', gap: 20 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <Badge variant={status} style={{ fontSize: 13, padding: '4px 12px' }}>{statusLabel[status]}</Badge>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text-3)' }}>{booking.id}</span>
          </div>
          <Divider />

          {/* Room + dates */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <DetailRow label="Kamar">
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 20, fontWeight: 500 }}>{room?.number}</span>
                <span style={{ fontSize: 14, color: 'var(--text-2)' }}>{room?.name}</span>
              </div>
            </DetailRow>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
              <DetailRow label="Check-in">
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 15, fontWeight: 500 }}>{formatDate(booking.checkIn)}</span>
              </DetailRow>
              <DetailRow label="Check-out">
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 15, fontWeight: 500 }}>{formatDate(booking.checkOut)}</span>
              </DetailRow>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
              <DetailRow label="Durasi" value={`${booking.nights} malam`} />
              <DetailRow label="Total Harga">
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 15, fontWeight: 500, color: 'var(--accent)' }}>{formatRupiah(booking.price)}</span>
              </DetailRow>
            </div>

            <DetailRow label="Sumber"><Badge variant={booking.source}>{sourceLabel[booking.source]}</Badge></DetailRow>
          </div>
          <Divider />

          {/* Notes */}
          <Textarea label="Catatan" value={notes} onChange={e => setNotes(e.target.value)} placeholder="Tambah catatan..." rows={3} />
        </Card>

        {/* Right — Guest info */}
        <Card style={{ padding: 24, display: 'flex', flexDirection: 'column', gap: 20 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span style={{ fontSize: 13, fontWeight: 500, color: 'var(--text-1)' }}>Data Tamu</span>
            <Btn variant="ghost" size="sm" onClick={() => setEditingGuest(!editingGuest)}>
              {editingGuest ? 'Simpan' : 'Edit'}
            </Btn>
          </div>
          <Divider />

          {booking.source !== 'direct' && !editingGuest ? (
            <div style={{ background: 'var(--surface)', borderRadius: 'var(--radius)', padding: '16px', display: 'flex', flexDirection: 'column', gap: 8, alignItems: 'center', textAlign: 'center' }}>
              <span style={{ fontSize: 13, color: 'var(--text-2)' }}>Data tamu belum diisi</span>
              <span style={{ fontSize: 12, color: 'var(--text-3)' }}>Pesanan dari {sourceLabel[booking.source]} — lengkapi data secara manual jika diperlukan.</span>
              <Btn variant="secondary" size="sm" onClick={() => setEditingGuest(true)} style={{ marginTop: 4 }}>Lengkapi Data</Btn>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <Input label="Nama Lengkap" value={booking.guest} readOnly={!editingGuest} />
              <Input label="Nomor HP" value={booking.phone} mono readOnly={!editingGuest} />
              <Input label="Email" value={booking.email} readOnly={!editingGuest} />
              <Input label="Nomor KTP / Identitas" value={booking.idNumber} mono readOnly={!editingGuest} placeholder="Belum diisi" />
            </div>
          )}
        </Card>
      </div>

      {/* Bottom actions */}
      <Card style={{ padding: '16px 20px', display: 'flex', alignItems: 'center', gap: 10 }}>
        <Btn variant="secondary" onClick={() => setShowExtendModal(true)}>Perpanjang Checkout</Btn>
        <Btn variant="secondary" onClick={() => { setStatus('completed'); showToast('Pemesanan ditandai selesai.'); }}>Tandai Selesai</Btn>
        <div style={{ flex: 1 }} />
        <Btn variant="danger" onClick={() => setShowCancelModal(true)}>Batalkan Pesanan</Btn>
      </Card>

      {/* Cancel modal */}
      <Modal open={showCancelModal} onClose={() => setShowCancelModal(false)} title="Batalkan Pesanan?">
        <p style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: 20, lineHeight: 1.6 }}>
          Pesanan <span style={{ fontFamily: 'var(--font-mono)', color: 'var(--text-1)' }}>{booking.id}</span> atas nama <strong>{booking.guest}</strong> akan dibatalkan. Tindakan ini tidak dapat dibatalkan.
        </p>
        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
          <Btn variant="secondary" onClick={() => setShowCancelModal(false)}>Batal</Btn>
          <Btn variant="danger" onClick={() => { setStatus('cancelled'); setShowCancelModal(false); showToast('Pesanan dibatalkan.'); }}>Ya, Batalkan</Btn>
        </div>
      </Modal>

      {/* Extend modal */}
      <Modal open={showExtendModal} onClose={() => setShowExtendModal(false)} title="Perpanjang Checkout">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <Input label="Tanggal Checkout Baru" type="date" value={extendDate} onChange={e => setExtendDate(e.target.value)} mono />
          <div style={{ background: 'var(--status-checkout-bg)', border: '1px solid #e8d5b0', borderRadius: 'var(--radius)', padding: '10px 12px', fontSize: 12, color: 'var(--status-checkout-fg)' }}>
            Periksa ketersediaan kamar sebelum memperpanjang.
          </div>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
            <Btn variant="secondary" onClick={() => setShowExtendModal(false)}>Batal</Btn>
            <Btn variant="primary" onClick={() => { setShowExtendModal(false); showToast('Checkout diperpanjang.'); }}>Simpan</Btn>
          </div>
        </div>
      </Modal>

      {/* Toast */}
      {toast && (
        <div style={{
          position: 'fixed', bottom: 24, left: '50%', transform: 'translateX(-50%)',
          background: 'var(--text-1)', color: '#fff', borderRadius: 'var(--radius)',
          padding: '10px 18px', fontSize: 13, zIndex: 200,
          boxShadow: '0 4px 16px rgba(26,25,22,0.18)',
          animation: 'fadeIn 150ms ease',
        }}>{toast}</div>
      )}
    </div>
  );
};

window.ScreenBookingDetail = ScreenBookingDetail;
