// Calendar / Gantt view

const DAY_W = 36;
const ROW_H = 44;
const LEFT_W = 160;

const DAYS_APRIL = 30;
const MONTH_LABEL = 'April 2026';
const MONTH_START = '2026-04-';
const TODAY_DAY = 28;

function dayNum(dateStr, monthPrefix) {
  if (!dateStr.startsWith(monthPrefix)) return null;
  return parseInt(dateStr.slice(monthPrefix.length), 10);
}

const sourceColors = {
  airbnb: { bg: 'var(--cal-airbnb)', text: 'var(--cal-airbnb-text)', border: '#e8a89e' },
  agoda:  { bg: 'var(--cal-agoda)',  text: 'var(--cal-agoda-text)',  border: '#9aaee8' },
  direct: { bg: 'var(--cal-direct)', text: 'var(--cal-direct-text)', border: '#8ec4a8' },
};

const Popover = ({ booking, room, x, y }) => {
  if (!booking) return null;
  const col = sourceColors[booking.source];
  return (
    <div style={{
      position: 'fixed', left: x + 12, top: y - 8,
      background: '#fff', border: '1px solid var(--border)',
      borderRadius: 'var(--radius-lg)', padding: '12px 14px',
      boxShadow: '0 4px 20px rgba(26,25,22,0.12)',
      zIndex: 50, minWidth: 200, pointerEvents: 'none',
    }}>
      <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 6 }}>{booking.guest}</div>
      <div style={{ fontSize: 12, color: 'var(--text-2)', display: 'flex', flexDirection: 'column', gap: 3 }}>
        <span><span style={{ color: 'var(--text-3)' }}>Kamar</span> {room?.number} — {room?.type}</span>
        <span style={{ fontFamily: 'var(--font-mono)' }}>{formatDate(booking.checkIn)} → {formatDate(booking.checkOut)}</span>
        <span>{booking.nights} malam · {formatRupiah(booking.price)}</span>
      </div>
      <div style={{ marginTop: 8 }}><Badge variant={booking.source}>{sourceLabel[booking.source]}</Badge></div>
    </div>
  );
};

const CalendarBlock = ({ booking, room, daysInMonth, monthPrefix, setPopover }) => {
  const startDay = dayNum(booking.checkIn, monthPrefix);
  const endDay = dayNum(booking.checkOut, monthPrefix);
  if (!startDay && !endDay) return null;

  const clampedStart = Math.max(startDay || 1, 1);
  const clampedEnd = Math.min(endDay || daysInMonth, daysInMonth);
  if (clampedEnd <= clampedStart) return null;

  const col = sourceColors[booking.source];
  const left = (clampedStart - 1) * DAY_W + 4;
  const width = (clampedEnd - clampedStart) * DAY_W - 8;

  return (
    <div
      onMouseEnter={e => setPopover({ booking, room, x: e.clientX, y: e.clientY })}
      onMouseMove={e => setPopover(p => p ? { ...p, x: e.clientX, y: e.clientY } : p)}
      onMouseLeave={() => setPopover(null)}
      style={{
        position: 'absolute', top: 7, left, width,
        height: ROW_H - 14, borderRadius: 4,
        background: col.bg, color: col.text,
        border: `1px solid ${col.border}`,
        display: 'flex', alignItems: 'center',
        padding: '0 8px', fontSize: 12, fontWeight: 500,
        whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
        cursor: 'pointer', userSelect: 'none',
        transition: 'filter 100ms',
      }}
      onMouseDown={e => e.currentTarget.style.filter = 'brightness(0.95)'}
      onMouseUp={e => e.currentTarget.style.filter = ''}
    >
      {booking.guest}
    </div>
  );
};

const ScreenCalendar = () => {
  const [popover, setPopover] = React.useState(null);
  const [month, setMonth] = React.useState({ label: 'April 2026', prefix: '2026-04-', days: 30, todayDay: 28 });

  const months = [
    { label: 'Maret 2026', prefix: '2026-03-', days: 31, todayDay: null },
    { label: 'April 2026', prefix: '2026-04-', days: 30, todayDay: 28 },
    { label: 'Mei 2026',   prefix: '2026-05-', days: 31, todayDay: null },
  ];
  const mIdx = months.findIndex(m => m.label === month.label);

  const days = Array.from({ length: month.days }, (_, i) => i + 1);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {/* Month nav */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
        <Btn variant="secondary" size="sm" onClick={() => mIdx > 0 && setMonth(months[mIdx - 1])} disabled={mIdx === 0}>←</Btn>
        <span style={{ fontSize: 14, fontWeight: 500, minWidth: 120, textAlign: 'center' }}>{month.label}</span>
        <Btn variant="secondary" size="sm" onClick={() => mIdx < months.length - 1 && setMonth(months[mIdx + 1])} disabled={mIdx === months.length - 1}>→</Btn>
        <div style={{ flex: 1 }} />
        {/* Legend */}
        <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
          {Object.entries(sourceColors).map(([src, col]) => (
            <span key={src} style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 12, color: 'var(--text-2)' }}>
              <span style={{ width: 12, height: 12, borderRadius: 3, background: col.bg, border: `1px solid ${col.border}`, display: 'inline-block' }} />
              {sourceLabel[src]}
            </span>
          ))}
        </div>
      </div>

      {/* Grid */}
      <div style={{ overflowX: 'auto', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)' }}>
        <div style={{ display: 'flex', minWidth: LEFT_W + month.days * DAY_W }}>
          {/* Left column header */}
          <div style={{ width: LEFT_W, flexShrink: 0 }}>
            {/* Header */}
            <div style={{
              height: 36, borderBottom: '1px solid var(--border-subtle)',
              borderRight: '1px solid var(--border-subtle)',
              display: 'flex', alignItems: 'center', padding: '0 16px',
              fontSize: 11, color: 'var(--text-3)', fontWeight: 500, textTransform: 'uppercase', letterSpacing: '0.04em',
              background: 'var(--surface)',
            }}>Kamar</div>
            {/* Room rows */}
            {ROOMS.map((room, i) => (
              <div key={room.id} style={{
                height: ROW_H,
                borderBottom: i < ROOMS.length - 1 ? '1px solid var(--border-subtle)' : 'none',
                borderRight: '1px solid var(--border-subtle)',
                display: 'flex', alignItems: 'center', padding: '0 16px',
                background: i % 2 === 0 ? 'var(--bg)' : 'rgba(242,240,236,0.4)',
              }}>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 13, color: 'var(--text-1)', marginRight: 8 }}>{room.number}</span>
                <span style={{ fontSize: 12, color: 'var(--text-3)' }}>{room.type}</span>
              </div>
            ))}
          </div>

          {/* Days area */}
          <div style={{ flex: 1, position: 'relative' }}>
            {/* Day headers */}
            <div style={{
              display: 'flex', height: 36,
              borderBottom: '1px solid var(--border-subtle)',
              background: 'var(--surface)',
            }}>
              {days.map(d => (
                <div key={d} style={{
                  width: DAY_W, flexShrink: 0, height: '100%',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 11, fontFamily: 'var(--font-mono)',
                  color: d === month.todayDay ? 'var(--accent)' : 'var(--text-3)',
                  fontWeight: d === month.todayDay ? 600 : 400,
                  borderRight: '1px solid var(--border-subtle)',
                  background: d === month.todayDay ? 'var(--accent-light)' : 'transparent',
                }}>{d}</div>
              ))}
            </div>

            {/* Room rows + booking blocks */}
            {ROOMS.map((room, i) => {
              const roomBookings = BOOKINGS.filter(b => b.roomId === room.id);
              return (
                <div key={room.id} style={{
                  height: ROW_H, position: 'relative',
                  borderBottom: i < ROOMS.length - 1 ? '1px solid var(--border-subtle)' : 'none',
                  background: i % 2 === 0 ? 'var(--bg)' : 'rgba(242,240,236,0.4)',
                }}>
                  {/* Today column highlight */}
                  {month.todayDay && (
                    <div style={{
                      position: 'absolute',
                      left: (month.todayDay - 1) * DAY_W, top: 0,
                      width: DAY_W, height: '100%',
                      background: 'rgba(61,107,82,0.04)',
                      pointerEvents: 'none',
                    }} />
                  )}
                  {/* Day grid lines */}
                  {days.map(d => (
                    <div key={d} style={{
                      position: 'absolute', left: d * DAY_W, top: 0,
                      width: 1, height: '100%',
                      background: 'var(--border-subtle)', pointerEvents: 'none',
                    }} />
                  ))}
                  {roomBookings.map(b => (
                    <CalendarBlock
                      key={b.id} booking={b} room={room}
                      daysInMonth={month.days} monthPrefix={month.prefix}
                      setPopover={setPopover}
                    />
                  ))}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {popover && <Popover booking={popover.booking} room={popover.room} x={popover.x} y={popover.y} />}
    </div>
  );
};

window.ScreenCalendar = ScreenCalendar;
