// Dashboard screen

const StatCard = ({ label, value, sub, accent }) => (
  <Card style={{ padding: '20px 22px', flex: 1, minWidth: 180 }}>
    <div style={{ fontSize: 12, color: 'var(--text-3)', fontWeight: 500, letterSpacing: '0.01em', textTransform: 'uppercase', marginBottom: 10 }}>{label}</div>
    <div style={{ fontSize: 26, fontWeight: 500, color: accent ? 'var(--accent)' : 'var(--text-1)', fontFamily: 'var(--font-mono)', letterSpacing: '-0.02em', lineHeight: 1 }}>{value}</div>
    {sub && <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 6 }}>{sub}</div>}
  </Card>
);

const RoomCard = ({ room }) => {
  const { status, booking } = getRoomStatus(room.id);
  const bgMap = {
    available: 'var(--bg)',
    occupied: 'var(--status-occupied-bg)',
    checkout: 'var(--status-checkout-bg)',
    confirmed: 'var(--status-confirmed-bg)',
    maintenance: 'var(--status-maintenance-bg)',
  };
  return (
    <div style={{
      background: bgMap[status] || 'var(--bg)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius)',
      padding: '12px 14px',
      position: 'relative',
      minHeight: 88,
      cursor: 'pointer',
      transition: 'border-color 120ms',
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 15, fontWeight: 500, color: 'var(--text-1)' }}>{room.number}</span>
        <StatusDot status={status} />
      </div>
      <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 2, marginBottom: 8 }}>{room.type}</div>
      {booking ? (
        <>
          <div style={{ fontSize: 12, fontWeight: 500, color: 'var(--text-1)' }}>{booking.guest}</div>
          <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 2, fontFamily: 'var(--font-mono)' }}>
            s/d {formatDateShort(booking.checkOut)}
          </div>
        </>
      ) : (
        <div style={{ fontSize: 12, color: 'var(--text-3)' }}>Tersedia</div>
      )}
    </div>
  );
};

const BookingRow = ({ booking, index }) => {
  const room = getRoomById(booking.roomId);
  const isEven = index % 2 === 0;
  return (
    <tr style={{ background: isEven ? 'transparent' : 'rgba(242,240,236,0.5)', cursor: 'pointer' }}
      onMouseEnter={e => e.currentTarget.style.background = 'var(--surface)'}
      onMouseLeave={e => e.currentTarget.style.background = isEven ? 'transparent' : 'rgba(242,240,236,0.5)'}
    >
      <td style={{ padding: '10px 14px', fontSize: 13 }}>{booking.guest}</td>
      <td style={{ padding: '10px 14px' }}>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text-2)' }}>
          {room?.number} <span style={{ color: 'var(--text-3)' }}>·</span> {room?.type}
        </span>
      </td>
      <td style={{ padding: '10px 14px', fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text-2)' }}>{formatDateShort(booking.checkIn)}</td>
      <td style={{ padding: '10px 14px', fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text-2)' }}>{formatDateShort(booking.checkOut)}</td>
      <td style={{ padding: '10px 14px' }}><Badge variant={booking.source}>{sourceLabel[booking.source]}</Badge></td>
      <td style={{ padding: '10px 14px' }}><Badge variant={booking.status}>{statusLabel[booking.status]}</Badge></td>
    </tr>
  );
};

const SyncStatus = () => (
  <div style={{ display: 'flex', alignItems: 'center', gap: 14, fontSize: 12, color: 'var(--text-3)' }}>
    <span>Terakhir sinkron: 5 menit lalu</span>
    <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
      <StatusDot status="available" />
      <span style={{ color: 'var(--text-2)' }}>Airbnb</span>
    </span>
    <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
      <StatusDot status="available" />
      <span style={{ color: 'var(--text-2)' }}>Agoda</span>
    </span>
  </div>
);

const ScreenDashboard = ({ onNavigate }) => {
  const today = '2026-04-28';
  const occupied = BOOKINGS.filter(b => b.checkIn <= today && b.checkOut > today && b.status === 'occupied').length;
  const checkoutToday = BOOKINGS.filter(b => b.checkOut === today).length;
  const available = ROOMS.length - occupied - checkoutToday;
  const revenue = BOOKINGS.filter(b => b.checkIn.startsWith('2026-04')).reduce((s, b) => s + b.price, 0);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 28 }}>
      {/* Stats row */}
      <div style={{ display: 'flex', gap: 14 }}>
        <StatCard label="Kamar Tersedia" value={available} sub={`dari ${ROOMS.length} total kamar`} />
        <StatCard label="Kamar Terisi" value={occupied} sub="tamu aktif hari ini" accent />
        <StatCard label="Checkout Hari Ini" value={checkoutToday} sub="perlu konfirmasi" />
        <StatCard label="Pendapatan Apr" value={formatRupiah(revenue)} sub="bulan berjalan" />
      </div>

      {/* Room grid */}
      <div>
        <h2 style={{ fontSize: 13, fontWeight: 500, color: 'var(--text-2)', marginBottom: 12, textTransform: 'uppercase', letterSpacing: '0.03em' }}>Status Kamar</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(155px, 1fr))', gap: 10 }}>
          {ROOMS.map(room => <RoomCard key={room.id} room={room} />)}
        </div>
      </div>

      {/* Booking table */}
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <h2 style={{ fontSize: 13, fontWeight: 500, color: 'var(--text-2)', textTransform: 'uppercase', letterSpacing: '0.03em' }}>Pemesanan Mendatang</h2>
          <Btn variant="ghost" size="sm" onClick={() => onNavigate('booking-detail')}>Lihat semua →</Btn>
        </div>
        <Card style={{ overflow: 'hidden', padding: 0 }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                {['Nama Tamu', 'Kamar', 'Masuk', 'Keluar', 'Sumber', 'Status'].map(h => (
                  <th key={h} style={{ padding: '10px 14px', textAlign: 'left', fontSize: 11, fontWeight: 500, color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '0.04em', whiteSpace: 'nowrap' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {BOOKINGS.slice(0, 6).map((b, i) => <BookingRow key={b.id} booking={b} index={i} />)}
            </tbody>
          </table>
          <div style={{ borderTop: '1px solid var(--border-subtle)', padding: '12px 14px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <SyncStatus />
            <Btn variant="ghost" size="sm" onClick={() => onNavigate('sync')}>Pengaturan sync</Btn>
          </div>
        </Card>
      </div>
    </div>
  );
};

window.ScreenDashboard = ScreenDashboard;
