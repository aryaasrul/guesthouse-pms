// Shared UI components — exports to window

const Badge = ({ variant = 'default', children, style }) => {
  const variantStyles = {
    available:    { background: 'var(--status-available-bg)',    color: 'var(--status-available-fg)' },
    occupied:     { background: 'var(--status-occupied-bg)',     color: 'var(--status-occupied-fg)' },
    checkout:     { background: 'var(--status-checkout-bg)',     color: 'var(--status-checkout-fg)' },
    maintenance:  { background: 'var(--status-maintenance-bg)',  color: 'var(--status-maintenance-fg)' },
    confirmed:    { background: 'var(--status-confirmed-bg)',    color: 'var(--status-confirmed-fg)' },
    pending:      { background: 'var(--status-pending-bg)',      color: 'var(--status-pending-fg)' },
    cancelled:    { background: 'var(--status-cancelled-bg)',    color: 'var(--status-cancelled-fg)' },
    airbnb:       { background: 'var(--airbnb-bg)',              color: 'var(--airbnb-fg)' },
    agoda:        { background: 'var(--agoda-bg)',               color: 'var(--agoda-fg)' },
    direct:       { background: 'var(--direct-bg)',              color: 'var(--direct-fg)' },
    default:      { background: 'var(--surface)',                color: 'var(--text-2)' },
  };
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      padding: '2px 8px', borderRadius: 'var(--radius-pill)',
      fontSize: 12, fontWeight: 500, lineHeight: '18px',
      whiteSpace: 'nowrap',
      ...variantStyles[variant],
      ...style,
    }}>{children}</span>
  );
};

const StatusDot = ({ status }) => {
  const colors = {
    available: 'var(--status-available-fg)',
    occupied: 'var(--status-occupied-fg)',
    checkout: 'var(--status-checkout-fg)',
    maintenance: 'var(--status-maintenance-fg)',
    confirmed: 'var(--status-confirmed-fg)',
    pending: 'var(--status-pending-fg)',
  };
  return (
    <span style={{
      display: 'inline-block', width: 7, height: 7,
      borderRadius: '50%', background: colors[status] || 'var(--text-3)',
      flexShrink: 0,
    }} />
  );
};

const Btn = ({ variant = 'primary', size = 'md', children, onClick, disabled, style }) => {
  const [hovered, setHovered] = React.useState(false);
  const base = {
    display: 'inline-flex', alignItems: 'center', gap: 6,
    border: 'none', cursor: disabled ? 'not-allowed' : 'pointer',
    fontFamily: 'var(--font-sans)', fontWeight: 500,
    borderRadius: 'var(--radius)', transition: 'background 120ms ease',
    opacity: disabled ? 0.5 : 1,
  };
  const sizes = {
    sm: { padding: '5px 10px', fontSize: 12 },
    md: { padding: '7px 14px', fontSize: 13 },
    lg: { padding: '10px 18px', fontSize: 14 },
  };
  const variants = {
    primary: { background: hovered ? 'var(--accent-hover)' : 'var(--accent)', color: '#fff' },
    secondary: { background: hovered ? 'var(--surface-raised)' : 'var(--surface)', color: 'var(--text-1)', border: '1px solid var(--border)' },
    ghost: { background: hovered ? 'var(--surface)' : 'transparent', color: 'var(--text-2)', border: '1px solid transparent' },
    danger: { background: hovered ? '#7a2e2e' : 'var(--status-occupied-bg)', color: 'var(--status-occupied-fg)', border: '1px solid #e5c5c5' },
  };
  return (
    <button
      onClick={onClick} disabled={disabled}
      onMouseEnter={() => setHovered(true)} onMouseLeave={() => setHovered(false)}
      style={{ ...base, ...sizes[size], ...variants[variant], ...style }}
    >{children}</button>
  );
};

const Input = ({ label, value, onChange, placeholder, type = 'text', mono, readOnly, style, inputStyle }) => (
  <div style={{ display: 'flex', flexDirection: 'column', gap: 5, ...style }}>
    {label && <label style={{ fontSize: 12, color: 'var(--text-2)', fontWeight: 500 }}>{label}</label>}
    <input
      type={type} value={value} onChange={onChange} placeholder={placeholder}
      readOnly={readOnly}
      style={{
        background: readOnly ? 'var(--surface)' : '#fff',
        border: '1px solid var(--border)', borderRadius: 'var(--radius)',
        padding: '7px 10px', fontSize: 13, color: 'var(--text-1)',
        fontFamily: mono ? 'var(--font-mono)' : 'var(--font-sans)',
        outline: 'none', width: '100%',
        ...inputStyle,
      }}
    />
  </div>
);

const Select = ({ label, value, onChange, children, style }) => (
  <div style={{ display: 'flex', flexDirection: 'column', gap: 5, ...style }}>
    {label && <label style={{ fontSize: 12, color: 'var(--text-2)', fontWeight: 500 }}>{label}</label>}
    <select value={value} onChange={onChange} style={{
      background: '#fff', border: '1px solid var(--border)',
      borderRadius: 'var(--radius)', padding: '7px 10px', fontSize: 13,
      color: 'var(--text-1)', outline: 'none', width: '100%', cursor: 'pointer',
    }}>{children}</select>
  </div>
);

const Textarea = ({ label, value, onChange, placeholder, rows = 3, style }) => (
  <div style={{ display: 'flex', flexDirection: 'column', gap: 5, ...style }}>
    {label && <label style={{ fontSize: 12, color: 'var(--text-2)', fontWeight: 500 }}>{label}</label>}
    <textarea
      value={value} onChange={onChange} placeholder={placeholder} rows={rows}
      style={{
        background: '#fff', border: '1px solid var(--border)',
        borderRadius: 'var(--radius)', padding: '8px 10px', fontSize: 13,
        color: 'var(--text-1)', outline: 'none', resize: 'vertical',
        fontFamily: 'var(--font-sans)', lineHeight: 1.5, width: '100%',
      }}
    />
  </div>
);

const Card = ({ children, style, onClick, hover }) => {
  const [hovered, setHovered] = React.useState(false);
  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        background: hovered && hover ? 'var(--surface)' : '#fff',
        border: '1px solid var(--border)',
        borderRadius: 'var(--radius-lg)',
        transition: 'background 120ms ease',
        cursor: onClick ? 'pointer' : 'default',
        ...style,
      }}
    >{children}</div>
  );
};

const Divider = ({ style }) => (
  <div style={{ height: 1, background: 'var(--border-subtle)', ...style }} />
);

const EmptyState = ({ message, action, onAction }) => (
  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 12, padding: '48px 24px', color: 'var(--text-3)' }}>
    <p style={{ fontSize: 13 }}>{message}</p>
    {action && <Btn variant="secondary" size="sm" onClick={onAction}>{action}</Btn>}
  </div>
);

const Modal = ({ open, onClose, title, children, width = 400 }) => {
  if (!open) return null;
  return (
    <div style={{
      position: 'fixed', inset: 0, background: 'rgba(26,25,22,0.32)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      zIndex: 100, backdropFilter: 'blur(2px)',
    }} onClick={onClose}>
      <div onClick={e => e.stopPropagation()} style={{
        background: '#fff', borderRadius: 'var(--radius-lg)',
        border: '1px solid var(--border)', width, maxWidth: 'calc(100vw - 32px)',
        padding: 24, boxShadow: '0 8px 32px rgba(26,25,22,0.12)',
      }}>
        {title && <h3 style={{ fontSize: 15, fontWeight: 500, marginBottom: 16 }}>{title}</h3>}
        {children}
      </div>
    </div>
  );
};

const statusLabel = { available: 'Tersedia', occupied: 'Terisi', checkout: 'Checkout', maintenance: 'Perawatan', confirmed: 'Konfirmasi', pending: 'Pending', cancelled: 'Dibatalkan' };
const sourceLabel = { airbnb: 'Airbnb', agoda: 'Agoda', direct: 'Direct' };

Object.assign(window, {
  Badge, StatusDot, Btn, Input, Select, Textarea,
  Card, Divider, EmptyState, Modal,
  statusLabel, sourceLabel,
});
