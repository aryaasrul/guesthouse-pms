// Layout — Sidebar + TopBar + shell

const NAV_ITEMS = [
  { id: 'dashboard',       label: 'Beranda',       icon: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6' },
  { id: 'calendar',        label: 'Kalender',      icon: 'M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z' },
  { id: 'booking-detail',  label: 'Pemesanan',     icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2' },
  { id: 'booking-form',    label: 'Buat Pesanan',  icon: 'M12 4v16m8-8H4' },
  { id: 'sync',            label: 'Sinkronisasi',  icon: 'M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15' },
  { id: 'public-room',     label: 'Halaman Publik',icon: 'M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064' },
  { id: 'design-system',   label: 'Design System', icon: 'M4 5a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1H5a1 1 0 01-1-1V5zm10 0a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1h-4a1 1 0 01-1-1V5zM4 15a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1H5a1 1 0 01-1-1v-4zm10 0a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1h-4a1 1 0 01-1-1v-4z' },
];

const NavIcon = ({ d, active }) => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
    stroke={active ? 'var(--accent)' : 'var(--text-3)'}
    strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d={d} />
  </svg>
);

const Sidebar = ({ current, onNavigate }) => (
  <aside style={{
    width: 'var(--sidebar-width)', height: '100vh', flexShrink: 0,
    borderRight: '1px solid var(--border)', background: 'var(--bg)',
    display: 'flex', flexDirection: 'column', position: 'sticky', top: 0,
    overflow: 'hidden',
  }}>
    {/* Property branding */}
    <div style={{ padding: '20px 20px 16px' }}>
      <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-1)', letterSpacing: '-0.01em' }}>
        {PROPERTY.name}
      </div>
      <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 2 }}>{PROPERTY.location}</div>
    </div>
    <Divider />

    {/* Nav */}
    <nav style={{ flex: 1, padding: '8px 10px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 1 }}>
      {NAV_ITEMS.map(item => {
        const active = current === item.id;
        return (
          <button key={item.id} onClick={() => onNavigate(item.id)} style={{
            display: 'flex', alignItems: 'center', gap: 9,
            padding: '7px 10px', borderRadius: 'var(--radius)',
            border: 'none', cursor: 'pointer', width: '100%', textAlign: 'left',
            background: active ? 'var(--accent-light)' : 'transparent',
            color: active ? 'var(--accent)' : 'var(--text-2)',
            fontSize: 13, fontWeight: active ? 500 : 400,
            fontFamily: 'var(--font-sans)',
            transition: 'background 100ms ease, color 100ms ease',
          }}
          onMouseEnter={e => { if (!active) e.currentTarget.style.background = 'var(--surface)'; }}
          onMouseLeave={e => { if (!active) e.currentTarget.style.background = 'transparent'; }}
          >
            <NavIcon d={item.icon} active={active} />
            {item.label}
          </button>
        );
      })}
    </nav>

    <Divider />
    {/* User footer */}
    <div style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 10 }}>
      <div style={{
        width: 28, height: 28, borderRadius: '50%',
        background: 'var(--accent-light)', color: 'var(--accent)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 11, fontWeight: 600, flexShrink: 0,
      }}>{PROPERTY.avatar}</div>
      <div>
        <div style={{ fontSize: 12, fontWeight: 500, color: 'var(--text-1)' }}>{PROPERTY.owner}</div>
        <div style={{ fontSize: 11, color: 'var(--text-3)' }}>Pemilik</div>
      </div>
    </div>
  </aside>
);

const TopBar = ({ title, subtitle, actions }) => (
  <header style={{
    height: 'var(--topbar-height)', borderBottom: '1px solid var(--border-subtle)',
    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
    padding: '0 32px', background: 'var(--bg)', flexShrink: 0,
    position: 'sticky', top: 0, zIndex: 10,
  }}>
    <div>
      <h1 style={{ fontSize: 15, fontWeight: 500, color: 'var(--text-1)', lineHeight: 1.2 }}>{title}</h1>
      {subtitle && <p style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 1 }}>{subtitle}</p>}
    </div>
    {actions && <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>{actions}</div>}
  </header>
);

const AppLayout = ({ current, onNavigate, topBar, children }) => (
  <div style={{ display: 'flex', height: '100vh', overflow: 'hidden' }}>
    <Sidebar current={current} onNavigate={onNavigate} />
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', minWidth: 0 }}>
      {topBar}
      <main style={{ flex: 1, overflowY: 'auto', padding: '28px 32px' }}>
        <div style={{ maxWidth: 'var(--max-content)', margin: '0 auto' }}>
          {children}
        </div>
      </main>
    </div>
  </div>
);

Object.assign(window, { Sidebar, TopBar, AppLayout, NavIcon });
