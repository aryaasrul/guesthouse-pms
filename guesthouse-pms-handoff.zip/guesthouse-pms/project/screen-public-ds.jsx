// Public booking page + Design System overview

// ─── Public Booking Page ───────────────────────────────────────────────────

const CalDay = ({ day, available }) => (
  <div style={{
    aspectRatio: '1', display: 'flex', alignItems: 'center', justifyContent: 'center',
    borderRadius: 'var(--radius-sm)', fontSize: 12, fontFamily: 'var(--font-mono)',
    background: !day ? 'transparent' : available ? 'transparent' : 'var(--surface)',
    color: !day ? 'transparent' : available ? 'var(--text-1)' : 'var(--text-3)',
    textDecoration: !available && day ? 'line-through' : 'none',
    cursor: available && day ? 'pointer' : 'default',
    transition: 'background 100ms',
  }}
  onMouseEnter={e => { if (available && day) e.currentTarget.style.background = 'var(--accent-light)'; }}
  onMouseLeave={e => { if (available && day) e.currentTarget.style.background = 'transparent'; }}
  >{day || ''}</div>
);

const ScreenPublicRoom = () => {
  const room = ROOMS[4]; // Suite Garden 05
  const [name, setName]       = React.useState('');
  const [phone, setPhone]     = React.useState('');
  const [checkIn, setCheckIn]  = React.useState('');
  const [checkOut, setCheckOut] = React.useState('');
  const [submitted, setSubmitted] = React.useState(false);

  // Generate April 2026 calendar
  const firstDay = new Date('2026-05-01').getDay(); // 0=Sun
  const totalDays = 31;
  const cells = [];
  for (let i = 0; i < firstDay; i++) cells.push(null);
  for (let d = 1; d <= totalDays; d++) cells.push(d);

  const unavailable = new Set([3, 4, 5, 10, 11, 12, 13, 18, 19]);

  const nights = React.useMemo(() => {
    if (!checkIn || !checkOut) return 0;
    return Math.max(0, (new Date(checkOut) - new Date(checkIn)) / 86400000);
  }, [checkIn, checkOut]);

  return (
    <div style={{ background: 'var(--bg)', minHeight: '100vh', fontFamily: 'var(--font-sans)' }}>
      {/* Minimal nav */}
      <div style={{ borderBottom: '1px solid var(--border)', padding: '16px 32px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <span style={{ fontSize: 14, fontWeight: 600, letterSpacing: '-0.01em' }}>{PROPERTY.name}</span>
        <span style={{ fontSize: 12, color: 'var(--text-3)' }}>{PROPERTY.location}</span>
      </div>

      <div style={{ maxWidth: 960, margin: '0 auto', padding: '40px 32px', display: 'grid', gridTemplateColumns: '1fr 380px', gap: 40, alignItems: 'start' }}>

        {/* Left — room info */}
        <div>
          {/* Hero placeholder */}
          <div style={{
            height: 280, borderRadius: 'var(--radius-lg)',
            background: 'var(--surface)',
            border: '1px solid var(--border)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            marginBottom: 28, overflow: 'hidden', position: 'relative',
          }}>
            {/* Warm-toned striped placeholder */}
            <svg width="100%" height="100%" style={{ position: 'absolute', inset: 0 }}>
              {Array.from({ length: 20 }).map((_, i) => (
                <rect key={i} x={i * 5 + '%'} y="0" width="2.5%" height="100%"
                  fill={i % 2 === 0 ? '#EAE6DF' : '#E2DDD5'} />
              ))}
            </svg>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--text-3)', position: 'relative', background: 'var(--surface)', padding: '4px 10px', borderRadius: 4 }}>
              foto kamar
            </span>
          </div>

          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 8 }}>
            <div>
              <h1 style={{ fontSize: 22, fontWeight: 500, letterSpacing: '-0.02em' }}>{room.name}</h1>
              <p style={{ fontSize: 13, color: 'var(--text-3)', marginTop: 4 }}>Kamar {room.number} · {room.type} · max {room.capacity} tamu</p>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 20, fontWeight: 500, color: 'var(--text-1)' }}>{formatRupiah(room.price)}</div>
              <div style={{ fontSize: 12, color: 'var(--text-3)' }}>per malam</div>
            </div>
          </div>

          <p style={{ fontSize: 13, color: 'var(--text-2)', lineHeight: 1.7, marginBottom: 28 }}>{room.description}</p>

          {/* Availability mini-calendar */}
          <div style={{ marginBottom: 8 }}>
            <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 12 }}>Ketersediaan — Mei 2026</div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 4, maxWidth: 280 }}>
              {['Min','Sen','Sel','Rab','Kam','Jum','Sab'].map(d => (
                <div key={d} style={{ textAlign: 'center', fontSize: 10, color: 'var(--text-3)', fontWeight: 500, padding: '0 0 4px' }}>{d}</div>
              ))}
              {cells.map((day, i) => (
                <CalDay key={i} day={day} available={day && !unavailable.has(day)} />
              ))}
            </div>
            <div style={{ display: 'flex', gap: 16, marginTop: 10, fontSize: 11, color: 'var(--text-3)' }}>
              <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}><span style={{ width: 10, height: 10, borderRadius: 2, background: 'var(--surface)', border: '1px solid var(--border)', display: 'inline-block' }} /> Tidak tersedia</span>
            </div>
          </div>
        </div>

        {/* Right — booking form */}
        <div style={{ position: 'sticky', top: 24 }}>
          <Card style={{ padding: 24 }}>
            {submitted ? (
              <div style={{ textAlign: 'center', padding: '24px 0', display: 'flex', flexDirection: 'column', gap: 12, alignItems: 'center' }}>
                <div style={{ width: 40, height: 40, borderRadius: '50%', background: 'var(--accent-light)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                </div>
                <div style={{ fontSize: 14, fontWeight: 500 }}>Permintaan dikirim!</div>
                <div style={{ fontSize: 12, color: 'var(--text-3)' }}>Pemilik akan menghubungi Anda dalam 1×24 jam.</div>
              </div>
            ) : (
              <>
                <div style={{ fontSize: 14, fontWeight: 500, marginBottom: 16 }}>Pesan Kamar Ini</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                  <Input label="Nama Lengkap" value={name} onChange={e => setName(e.target.value)} placeholder="Nama Anda" />
                  <Input label="Nomor HP" value={phone} onChange={e => setPhone(e.target.value)} placeholder="08xx-xxxx-xxxx" mono />
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                    <Input label="Check-in" type="date" value={checkIn} onChange={e => setCheckIn(e.target.value)} mono />
                    <Input label="Check-out" type="date" value={checkOut} onChange={e => setCheckOut(e.target.value)} mono />
                  </div>
                  {nights > 0 && (
                    <div style={{ background: 'var(--surface)', borderRadius: 'var(--radius)', padding: '10px 12px', display: 'flex', justifyContent: 'space-between', fontSize: 13 }}>
                      <span style={{ color: 'var(--text-2)' }}>{nights} malam</span>
                      <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 500 }}>{formatRupiah(room.price * nights)}</span>
                    </div>
                  )}
                  <Btn variant="primary" style={{ width: '100%', justifyContent: 'center', padding: '10px' }}
                    disabled={!name || !phone || !checkIn || !checkOut}
                    onClick={() => setSubmitted(true)}>
                    Kirim Permintaan
                  </Btn>
                  <p style={{ fontSize: 11, color: 'var(--text-3)', textAlign: 'center' }}>Pembayaran dikonfirmasi langsung dengan pemilik.</p>
                </div>
              </>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
};

// ─── Design System Overview ────────────────────────────────────────────────

const DSSection = ({ title, children }) => (
  <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
    <h3 style={{ fontSize: 11, fontWeight: 500, color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{title}</h3>
    {children}
  </div>
);

const Swatch = ({ bg, label, hex }) => (
  <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
    <div style={{ height: 48, borderRadius: 'var(--radius)', background: bg, border: '1px solid var(--border)' }} />
    <div style={{ fontSize: 11, color: 'var(--text-2)', fontWeight: 500 }}>{label}</div>
    <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text-3)' }}>{hex}</div>
  </div>
);

const ScreenDesignSystem = () => (
  <div style={{ display: 'flex', flexDirection: 'column', gap: 40 }}>

    {/* Colors */}
    <DSSection title="Palette">
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(90px,1fr))', gap: 12 }}>
        <Swatch bg="#FAFAF8" label="bg" hex="#FAFAF8" />
        <Swatch bg="#F2F0EC" label="surface" hex="#F2F0EC" />
        <Swatch bg="#EDEAE4" label="surface-raised" hex="#EDEAE4" />
        <Swatch bg="#E8E4DE" label="border" hex="#E8E4DE" />
        <Swatch bg="#1A1916" label="text-1" hex="#1A1916" />
        <Swatch bg="#6B6862" label="text-2" hex="#6B6862" />
        <Swatch bg="#A8A49E" label="text-3" hex="#A8A49E" />
        <Swatch bg="#3D6B52" label="accent" hex="#3D6B52" />
        <Swatch bg="#EEF5F0" label="accent-light" hex="#EEF5F0" />
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(130px,1fr))', gap: 10 }}>
        {[
          { label: 'Tersedia', bg: '#EEF5F0', fg: '#4A7C59' },
          { label: 'Terisi', bg: '#F9EEEE', fg: '#8B3A3A' },
          { label: 'Checkout', bg: '#FBF4E8', fg: '#7A5C2E' },
          { label: 'Perawatan', bg: '#EFEFEE', fg: '#6B6862' },
          { label: 'Konfirmasi', bg: '#EEF0F8', fg: '#3A5280' },
          { label: 'Pending', bg: '#FBF4E8', fg: '#7A5C2E' },
          { label: 'Dibatalkan', bg: '#F2F2F1', fg: '#888580' },
        ].map(s => (
          <div key={s.label} style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <div style={{ height: 32, borderRadius: 'var(--radius)', background: s.bg, border: `1px solid ${s.fg}30`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <span style={{ fontSize: 11, fontWeight: 500, color: s.fg }}>{s.label}</span>
            </div>
          </div>
        ))}
      </div>
    </DSSection>

    {/* Typography */}
    <DSSection title="Typography">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {[
          { label: 'Heading / 22px / 500', size: 22, weight: 500, text: 'Villa Pandan' },
          { label: 'Title / 15px / 500', size: 15, weight: 500, text: 'Dashboard Pemesanan' },
          { label: 'Body / 14px / 400', size: 14, weight: 400, text: 'Tamu aktif saat ini: 3 kamar dari 8 tersedia.' },
          { label: 'Small / 13px / 400', size: 13, weight: 400, text: 'Checkout hari ini perlu konfirmasi sebelum jam 12.00.' },
          { label: 'Caption / 12px / 400', size: 12, weight: 400, text: 'Terakhir disinkronkan 5 menit lalu · Airbnb ✓ · Agoda ✓', color: 'var(--text-3)' },
          { label: 'Mono — booking ID', size: 13, weight: 400, text: 'BK-0042 · Rp 1.750.000 · 28 Apr 2026', mono: true },
          { label: 'Mono — room number', size: 20, weight: 500, text: '05', mono: true },
        ].map(t => (
          <div key={t.label} style={{ display: 'flex', alignItems: 'baseline', gap: 20, padding: '8px 0', borderBottom: '1px solid var(--border-subtle)' }}>
            <span style={{ fontSize: 11, color: 'var(--text-3)', width: 220, flexShrink: 0, fontFamily: 'var(--font-mono)' }}>{t.label}</span>
            <span style={{ fontSize: t.size, fontWeight: t.weight, fontFamily: t.mono ? 'var(--font-mono)' : 'var(--font-sans)', color: t.color || 'var(--text-1)' }}>{t.text}</span>
          </div>
        ))}
      </div>
    </DSSection>

    {/* Badges */}
    <DSSection title="Badges & Status">
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, alignItems: 'center' }}>
        {['available','occupied','checkout','maintenance','confirmed','pending','cancelled'].map(v => (
          <Badge key={v} variant={v}>{statusLabel[v]}</Badge>
        ))}
        {['airbnb','agoda','direct'].map(v => (
          <Badge key={v} variant={v}>{sourceLabel[v]}</Badge>
        ))}
      </div>
    </DSSection>

    {/* Buttons */}
    <DSSection title="Buttons">
      <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'center' }}>
        <Btn variant="primary">Buat Pesanan</Btn>
        <Btn variant="secondary">Perpanjang Checkout</Btn>
        <Btn variant="ghost">Lihat Semua →</Btn>
        <Btn variant="danger">Batalkan Pesanan</Btn>
        <Btn variant="primary" disabled>Disabled</Btn>
        <Btn variant="primary" size="sm">Small</Btn>
        <Btn variant="secondary" size="lg">Large</Btn>
      </div>
    </DSSection>

    {/* Inputs */}
    <DSSection title="Form Controls">
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, maxWidth: 800 }}>
        <Input label="Nama Tamu" placeholder="Nama sesuai KTP" />
        <Input label="Nomor HP" placeholder="08xx-xxxx-xxxx" mono />
        <Input label="Check-in" type="date" value="2026-05-05" mono />
        <Select label="Sumber Pesanan"><option>Direct</option><option>Airbnb</option><option>Agoda</option></Select>
        <Textarea label="Catatan" placeholder="Permintaan khusus..." rows={2} style={{ gridColumn: 'span 2' }} />
      </div>
    </DSSection>

    {/* Spacing scale */}
    <DSSection title="Spacing — 8px grid">
      <div style={{ display: 'flex', gap: 16, alignItems: 'flex-end' }}>
        {[4, 8, 12, 16, 24, 32, 40, 48].map(n => (
          <div key={n} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
            <div style={{ width: 16, height: n, background: 'var(--accent-light)', border: '1px solid var(--accent)', borderRadius: 2 }} />
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text-3)' }}>{n}</span>
          </div>
        ))}
      </div>
    </DSSection>
  </div>
);

window.ScreenPublicRoom   = ScreenPublicRoom;
window.ScreenDesignSystem = ScreenDesignSystem;
