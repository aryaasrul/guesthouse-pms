// Mock data for Guesthouse PMS

const PROPERTY = {
  name: 'Villa Pandan',
  location: 'Malang, Jawa Timur',
  owner: 'Pak Hendra',
  avatar: 'PH',
};

const ROOMS = [
  { id: 1, number: '01', name: 'Kamar Standar', type: 'Standard', price: 350000, capacity: 2, description: 'Kamar nyaman dengan tempat tidur queen, AC, dan kamar mandi dalam.' },
  { id: 2, number: '02', name: 'Kamar Standar', type: 'Standard', price: 350000, capacity: 2, description: 'Kamar nyaman dengan tempat tidur queen, AC, dan kamar mandi dalam.' },
  { id: 3, number: '03', name: 'Kamar Deluxe', type: 'Deluxe', price: 500000, capacity: 2, description: 'Kamar luas dengan pemandangan taman, tempat tidur king, dan bathtub.' },
  { id: 4, number: '04', name: 'Kamar Deluxe', type: 'Deluxe', price: 500000, capacity: 2, description: 'Kamar luas dengan pemandangan taman, tempat tidur king, dan bathtub.' },
  { id: 5, number: '05', name: 'Suite Garden', type: 'Suite', price: 750000, capacity: 3, description: 'Suite eksklusif dengan teras pribadi menghadap taman hijau.' },
  { id: 6, number: '06', name: 'Suite Garden', type: 'Suite', price: 750000, capacity: 3, description: 'Suite eksklusif dengan teras pribadi menghadap taman hijau.' },
  { id: 7, number: '07', name: 'Kamar Family', type: 'Family', price: 850000, capacity: 4, description: 'Kamar keluarga besar dengan dua tempat tidur dan ruang duduk.' },
  { id: 8, number: '08', name: 'Kamar Family', type: 'Family', price: 850000, capacity: 4, description: 'Kamar keluarga besar dengan dua tempat tidur dan ruang duduk.' },
];

const BOOKINGS = [
  {
    id: 'BK-0001', roomId: 1, guest: 'Budi Santoso',
    phone: '0812-3456-7890', email: 'budi.santoso@gmail.com', idNumber: '3578012345670001',
    checkIn: '2026-04-26', checkOut: '2026-04-30',
    nights: 4, price: 1400000, source: 'direct', status: 'occupied',
    notes: 'Tamu reguler, sering menginap tiap bulan.',
  },
  {
    id: 'BK-0002', roomId: 3, guest: 'Siti Rahayu',
    phone: '0898-7654-3210', email: 'siti.rahayu@email.com', idNumber: '3578029876540002',
    checkIn: '2026-04-27', checkOut: '2026-05-02',
    nights: 5, price: 2500000, source: 'airbnb', status: 'occupied',
    notes: '',
  },
  {
    id: 'BK-0003', roomId: 5, guest: 'Ahmad Fauzi',
    phone: '0876-5432-1098', email: 'ahmad.fauzi@mail.com', idNumber: '3578036543210003',
    checkIn: '2026-04-25', checkOut: '2026-04-28',
    nights: 3, price: 2250000, source: 'agoda', status: 'checkout',
    notes: 'Tamu dari Surabaya, perlu kuitansi.',
  },
  {
    id: 'BK-0004', roomId: 7, guest: 'Maya Kusuma',
    phone: '0823-4567-8901', email: 'maya.k@gmail.com', idNumber: '3578044567890004',
    checkIn: '2026-04-29', checkOut: '2026-05-03',
    nights: 4, price: 3400000, source: 'airbnb', status: 'confirmed',
    notes: 'Pesan extra bed untuk anak.',
  },
  {
    id: 'BK-0005', roomId: 2, guest: 'Dewi Anggraeni',
    phone: '0834-5678-9012', email: 'dewi.a@email.com', idNumber: '3578055678900005',
    checkIn: '2026-05-01', checkOut: '2026-05-04',
    nights: 3, price: 1050000, source: 'direct', status: 'confirmed',
    notes: '',
  },
  {
    id: 'BK-0006', roomId: 4, guest: 'Rudi Hermawan',
    phone: '0845-6789-0123', email: 'rudi.h@mail.com', idNumber: '',
    checkIn: '2026-05-02', checkOut: '2026-05-05',
    nights: 3, price: 1500000, source: 'agoda', status: 'pending',
    notes: '',
  },
  {
    id: 'BK-0007', roomId: 6, guest: 'Lina Wijaya',
    phone: '0856-7890-1234', email: 'lina.w@gmail.com', idNumber: '3578067890120007',
    checkIn: '2026-05-03', checkOut: '2026-05-06',
    nights: 3, price: 2250000, source: 'direct', status: 'confirmed',
    notes: '',
  },
  {
    id: 'BK-0008', roomId: 8, guest: 'Farhan Pratama',
    phone: '0867-8901-2345', email: '', idNumber: '',
    checkIn: '2026-04-28', checkOut: '2026-05-01',
    nights: 3, price: 2550000, source: 'airbnb', status: 'occupied',
    notes: 'Late check-in, tiba sekitar jam 22.00.',
  },
];

const SYNC_CHANNELS = [
  {
    id: 'airbnb', name: 'Airbnb', color: '#FF5A5F',
    rooms: [1, 2, 3, 4, 5, 6],
    icalUrl: 'https://www.airbnb.com/calendar/ical/1234567890.ics?s=abc123xyz',
    lastSync: '2026-04-28T06:48:00', eventsFound: 12, eventsAdded: 2, status: 'active', result: 'ok',
  },
  {
    id: 'agoda', name: 'Agoda', color: '#003580',
    rooms: [1, 2, 3, 4],
    icalUrl: 'https://www.agoda.com/ical/export?hotel_id=98765&token=def456uvw',
    lastSync: '2026-04-28T06:50:00', eventsFound: 8, eventsAdded: 1, status: 'active', result: 'ok',
  },
];

const SYNC_LOGS = [
  { id: 1, channel: 'airbnb', timestamp: '2026-04-28T06:48:00', eventsFound: 12, eventsAdded: 2, status: 'ok' },
  { id: 2, channel: 'agoda',  timestamp: '2026-04-28T06:50:00', eventsFound: 8,  eventsAdded: 1, status: 'ok' },
  { id: 3, channel: 'airbnb', timestamp: '2026-04-28T01:48:00', eventsFound: 12, eventsAdded: 0, status: 'ok' },
  { id: 4, channel: 'agoda',  timestamp: '2026-04-28T01:50:00', eventsFound: 8,  eventsAdded: 0, status: 'ok' },
  { id: 5, channel: 'airbnb', timestamp: '2026-04-27T18:48:00', eventsFound: 11, eventsAdded: 3, status: 'ok' },
  { id: 6, channel: 'agoda',  timestamp: '2026-04-27T18:50:00', eventsFound: 7,  eventsAdded: 1, status: 'ok' },
  { id: 7, channel: 'airbnb', timestamp: '2026-04-27T12:48:00', eventsFound: 8,  eventsAdded: 0, status: 'ok' },
  { id: 8, channel: 'agoda',  timestamp: '2026-04-27T12:50:00', eventsFound: 6,  eventsAdded: 0, status: 'error' },
  { id: 9, channel: 'airbnb', timestamp: '2026-04-27T06:48:00', eventsFound: 8,  eventsAdded: 1, status: 'ok' },
  { id: 10, channel: 'agoda', timestamp: '2026-04-27T06:50:00', eventsFound: 6,  eventsAdded: 2, status: 'ok' },
];

// helpers
function formatRupiah(n) {
  return 'Rp ' + n.toLocaleString('id-ID');
}
function formatDate(str) {
  if (!str) return '—';
  const d = new Date(str);
  return d.toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' });
}
function formatDateShort(str) {
  if (!str) return '—';
  const d = new Date(str);
  return d.toLocaleDateString('id-ID', { day: 'numeric', month: 'short' });
}
function formatTime(str) {
  if (!str) return '—';
  const d = new Date(str);
  return d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
}
function getRoomById(id) { return ROOMS.find(r => r.id === id); }
function getRoomStatus(roomId) {
  const today = '2026-04-28';
  const b = BOOKINGS.find(bk => bk.roomId === roomId && bk.checkIn <= today && bk.checkOut > today);
  if (!b) return { status: 'available', booking: null };
  if (b.checkOut === today) return { status: 'checkout', booking: b };
  return { status: b.status === 'occupied' ? 'occupied' : b.status, booking: b };
}
