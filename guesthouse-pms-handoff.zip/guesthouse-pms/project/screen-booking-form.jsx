// Booking form screen — manual entry

const RoomSelectorCard = ({ room, selected, available, takenBy, onClick }) => {
  const [hovered, setHovered] = React.useState(false);
  return (
    <div
      onClick={() => available && onClick(room.id)}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      title={!available && takenBy ? `Terisi — ${takenBy}` : ''}
      style={{
        border: `1.5px solid ${selected ? 'var(--accent)' : available ? (hovered ? 'var(--border)' : 'var(--border-subtle)') : 'var(--border-subtle)'}`,
        borderRadius: 'var(--radius)',
        padding: '12px 14px',
        cursor: available ? 'pointer' : 'not-allowed',
        background: selected ? 'var(--accent-light)' : !available ? 'var(--surface)' : hovered ? 'rgba(61,107,82,0.03)' : '#fff',
        opacity: available ? 1 : 0.55,
        transition: 'border-color 100ms, background 100ms',
        position: 'relative',
      }}
    >
      <div style={{ fontFamily: 'var(--font-mono)', fontSize: 16, fontWeight: 500, color: selected ? 'var(--accent)' : available ? 'var(--text-1)' : 'var(--text-3)' }}>{room.number}</div>
      <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 2 }}>{room.type}</div>
      <div style={{ fontSize: 11, fontFamily: 'var(--font-mono)', color: selected ? 'var(--accent)' : 'var(--text-3)', marginTop: 4 }}>{formatRupiah(room.price)}<span style={{ fontFamily: 'var(--font-sans)' }}>/mlm</span></div>
      {!available && (
        <div style={{
          position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
          borderRadius: 'var(--radius)',
        }}>
          <span style={{ fontSize: 10, color: 'var(--text-3)', textAlign: 'center', padding: '0 8px' }}>Terisi</span>
        </div>
      )}
    </div>
  );
};

const ScreenBookingForm = ({ onNavigate }) => {
  const [checkIn, setCheckIn]   = React.useState('2026-05-05');
  const [checkOut, setCheckOut] = React.useState('2026-05-08');
  const [selectedRoom, setSelectedRoom] = React.useState(null);
  const [guestName, setGuestName]   = React.useState('');
  const [phone, setPhone]           = React.useState('');
  const [idNumber, setIdNumber]     = React.useState('');
  const [price, setPrice]           = React.useState('');
  const [notes, setNotes]           = React.useState('');
  const [source]                    = React.useState('direct');
  const [submitted, setSubmitted]   = React.useState(false);

  const nights = React.useMemo(() => {
    if (!checkIn || !checkOut) return 0;
    const d = (new Date(checkOut) - new Date(checkIn)) / 86400000;
    return Math.max(0, d);
  }, [checkIn, checkOut]);

  // Which rooms are available for these dates?
  const roomAvailability = React.useMemo(() => {
    return ROOMS.map(room => {
      const conflict = BOOKINGS.find(b =>
        b.roomId === room.id &&
        b.checkIn < checkOut && b.checkOut > checkIn
      );
      return { room, available: !conflict, takenBy: conflict?.guest };
    });
  }, [checkIn, checkOut]);

  React.useEffect(() => {
    if (selectedRoom) {
      const room = ROOMS.find(r => r.id === selectedRoom);
      if (room) setPrice(String(room.price * nights));
    }
  }, [selectedRoom, nights]);

  // Check selected room still available when dates change
  React.useEffect(() => {
    if (selectedRoom) {
      const avail = roomAvailability.find(a => a.room.id === selectedRoom);
      if (!avail?.available) setSelectedRoom(null);
    }
  }, [roomAvailability]);

  const datesSelected = checkIn && checkOut && nights > 0;

  if (submitted) {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 16, padding: '80px 24px', textAlign: 'center' }}>
        <div style={{ width: 48, height: 48, borderRadius: '50%', background: 'var(--accent-light)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12" /></svg>
        </div>
        <div>
          <div style={{ fontSize: 15, fontWeight: 500 }}>Pesanan berhasil dibuat</div>
          <div style={{ fontSize: 13, color: 'var(--text-3)', marginTop: 4 }}>ID pesanan baru: <span style={{ fontFamily: 'var(--font-mono)' }}>BK-0009</span></div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <Btn variant="secondary" onClick={() => setSubmitted(false)}>Buat Lagi</Btn>
          <Btn variant="primary" onClick={() => onNavigate('dashboard')}>Ke Dashboard</Btn>
        </div>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: 600, display: 'flex', flexDirection: 'column', gap: 24 }}>

      {/* Dates */}
      <Card style={{ padding: 20 }}>
        <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 16 }}>Tanggal Menginap</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
          <Input label="Check-in" type="date" value={checkIn} onChange={e => setCheckIn(e.target.value)} mono />
          <Input label="Check-out" type="date" value={checkOut} onChange={e => setCheckOut(e.target.value)} mono />
        </div>
        {datesSelected && (
          <div style={{ marginTop: 10, fontSize: 12, color: 'var(--text-3)' }}>
            {nights} malam · {formatDate(checkIn)} — {formatDate(checkOut)}
          </div>
        )}
      </Card>

      {/* Room selector */}
      <Card style={{ padding: 20 }}>
        <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 4 }}>Pilih Kamar</div>
        {!datesSelected ? (
          <p style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 8 }}>Pilih tanggal terlebih dahulu untuk melihat ketersediaan.</p>
        ) : (
          <>
            <p style={{ fontSize: 12, color: 'var(--text-3)', marginBottom: 12 }}>
              {roomAvailability.filter(a => a.available).length} kamar tersedia untuk tanggal yang dipilih
            </p>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
              {roomAvailability.map(({ room, available, takenBy }) => (
                <RoomSelectorCard
                  key={room.id} room={room} available={available} takenBy={takenBy}
                  selected={selectedRoom === room.id}
                  onClick={setSelectedRoom}
                />
              ))}
            </div>
          </>
        )}
      </Card>

      {/* Guest info */}
      <Card style={{ padding: 20 }}>
        <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 16 }}>Data Tamu</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <Input label="Nama Lengkap" value={guestName} onChange={e => setGuestName(e.target.value)} placeholder="Nama sesuai KTP" />
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            <Input label="Nomor HP" value={phone} onChange={e => setPhone(e.target.value)} placeholder="08xx-xxxx-xxxx" mono />
            <Input label="Nomor KTP" value={idNumber} onChange={e => setIdNumber(e.target.value)} placeholder="16 digit" mono />
          </div>
        </div>
      </Card>

      {/* Price + notes */}
      <Card style={{ padding: 20 }}>
        <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 16 }}>Detail Pembayaran</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, alignItems: 'end' }}>
            <Input
              label="Total Harga (Rp)"
              value={price} onChange={e => setPrice(e.target.value)}
              placeholder="0" mono
            />
            <div style={{ padding: '7px 0', fontSize: 12, color: 'var(--text-3)' }}>
              Sumber: <Badge variant="direct">Direct</Badge>
            </div>
          </div>
          <Textarea label="Catatan (opsional)" value={notes} onChange={e => setNotes(e.target.value)} placeholder="Permintaan khusus, catatan untuk staf..." rows={2} />
        </div>
      </Card>

      {/* Submit */}
      <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
        <Btn variant="secondary" onClick={() => onNavigate('dashboard')}>Batal</Btn>
        <Btn
          variant="primary"
          disabled={!guestName || !selectedRoom || !datesSelected}
          onClick={() => setSubmitted(true)}
        >
          Buat Pesanan
        </Btn>
      </div>
    </div>
  );
};

window.ScreenBookingForm = ScreenBookingForm;
